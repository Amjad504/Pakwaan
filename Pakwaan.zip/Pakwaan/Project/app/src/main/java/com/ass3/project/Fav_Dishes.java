package com.ass3.project;


public class Fav_Dishes {
    public String link;

    public Fav_Dishes(String link) {
        this.link = link;
    }

    public Fav_Dishes() {

    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
